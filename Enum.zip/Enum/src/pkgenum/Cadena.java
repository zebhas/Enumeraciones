/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgenum;


public enum Cadena {
    MATEMATICAS ("PERDIDO",29)
    ,ESPAÑOL ("APROBADO",48)
    ,SOCIALES ("APROBADO",45)
    ,BIOLOGIA("PERDIDO",15);
    
    private final String Estado;
    private final int nota;

    private Cadena(String Estado, int nota) {
        this.Estado = Estado;
        this.nota = nota;
    }

    public String getEstado() {
        return Estado;
    }

    public int getNota() {
        return nota;
    }
    
    
    
    
    
    
}
