/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enum2;

/**
 *
 * @author Guest
 */
public enum videojuego {
    MARIO ("EXCELENTE SAJA DE VIDEOJUEGOS",8),
    ZELDA("LA MEJOR SAGA DE VIDEOJUEGOS DE TODAS", 10),
    SONIC ("MALA SAGA DE VIDEOJUEGOS",4 );
    
    private final String comentario;
    private final int calificación;

    private videojuego(String comentario, int calificación) {
        this.comentario = comentario;
        this.calificación = calificación;
    }

    public String getComentario() {
        return comentario;
    }

    public int getCalificacion() {
        return calificación;
    }
    
    
    
    
}
